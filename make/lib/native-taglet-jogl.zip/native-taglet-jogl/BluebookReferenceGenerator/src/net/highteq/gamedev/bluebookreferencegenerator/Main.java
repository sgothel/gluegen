/*
 * Main.java
 *
 * Created on 25. Februar 2006, 14:38
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.highteq.gamedev.bluebookreferencegenerator;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.DOMReader;
import org.w3c.tidy.Tidy;

/**
 *
 * @author mhenze
 */
public class Main
{
	
	/** Creates a new instance of Main */
	public Main()
	{
	}
	
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args)
	{
		String baseUrl="http://www.rush3d.com/reference/opengl-bluebook-1.0/";
		Properties mapping= new Properties();
		mapping.put("nativetaglet.baseUrl",baseUrl);
		Tidy tidy= new Tidy();
		InputStream in= null;
		FileOutputStream out= null;
		try
		{
			URL url= new URL(baseUrl+"index.html");
			in= url.openStream();
			Document doc= new DOMReader().read(tidy.parseDOM(in, null));
			List result= doc.selectNodes("//a[starts-with(string(.),'gl')]");
			for (Iterator it = result.iterator(); it.hasNext();)
			{
				Element elem = (Element) it.next();
				mapping.put(elem.getStringValue(),((Element)elem).attributeValue("href"));
				System.out.println("added "+elem.getStringValue()+"="+((Element)elem).attributeValue("href"));
			}
			out= new FileOutputStream("native-taglet.properties");
			mapping.store(out,"#OpenGL Reference Manual method name mapping");
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if(in!=null) try{ in.close(); } catch (IOException ex) { ex.printStackTrace(); }
			if(out!=null) try{ out.flush(); out.close(); } catch (IOException ex) { ex.printStackTrace(); }
		}
	}
}
