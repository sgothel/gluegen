This package contains the taglet prototype to generate links to existing
documentation for JOGL native calls.

Author:   Mathias Henze (with modifications by Kenneth Russell)
Licence:  Unrestricted usage and distribution in source and binary form.
Warranty: None. The author is not responsible for any physical or mental
          damage caused by the use of this software =)

CONTENTS
========

BluebookReferenceGenerator .... The sources of a tool to generate the needed
                                mapping-file from a website
native-taglet ................. The sources of the taglet to evaluate @native
                                tags in javadoc comments
native-taglet-1.0.jar ......... The compiled version of the taglet, ready for
                                inclusion in the javadoc build process
native-taglet.properties ...... The configuration file of the native taglet,
                                that contains the mapping from names to URLs
gluegen-src-patch.txt ......... The patch to the gluegen src-directory to
                                enable @native tag generation inside gluegen
Readme.txt .................... This file ;)


USAGE
=====
- Put the "native-taglet-1.0.jar" in the "jogl/make" directory
- Put the "native-taglet.properties" in the "jogl/make" directory
- Patch the gluegen sources using "gluegen-src-patch.txt"
- Add the line "TagNativeBinding true" to the gluegen configuration files
  (gl-<platform>.cfg, glu-<platform>.cfg)
- Nest the line
  <taglet name="net.highteq.nativetaglet.NativeTaglet" path="native-taglet-1.0.jar"/>
  inside the <javadoc>-tags in the file "jogl/make/build.xml"
- run "ant javadoc" from the commandline in "jogl/make"

NOTES
=====
The "BluebookReferenceGenerator" is a Netbeans project and requires "JTidy"
(http://sourceforge.net/projects/jtidy), DOM4J (http://www.dom4j.org/) and
jaxon (http://jaxen.codehaus.org/)

The "native-taglet" compiles fine without Netbeans but includes a project
folder for convenience. The build file asumes tht JAVA_HOME variable to
point to a valid JDK since the compilation requires the "tools.jar"

The patch to gluegen adds the "TagNativeBinding" configuration option to
the "JavaConfiguration" class which defaults to "false". The patch also adds
the @native tag generation to the "JavaMethodBindingEmitter" class. Therefor
it changes to base class JavaEmitter, too.

The "native-taglet.properties" contains simple <name>=<URL> mappings, where
<name> ist the name of the native method and <URL> is a location relative to
the URL mapped by the "nativetaglet.baseUrl" key.

===

  Enjoy!
